# Politica de seguridad

## Versiones admitidas

Use esta sección para decirle a la gente qué versiones de su proyecto están 
actualmente es compatible con actualizaciones de seguridad.

| Version | Soportado       |
| ------- | ------------------ |
| 5.1.x   | :white_check_mark: |
| 5.0.x   | :x:                |
| 4.0.x   | :white_check_mark: |
| < 4.0   | :x:                |

## Informar de una vulnerabilidad

Utilice esta sección para decirle a las personas cómo informar una vulnerabilidad.

Dígales adónde ir, con qué frecuencia pueden esperar recibir una actualización sobre un
vulnerabilidad reportada, qué esperar si la vulnerabilidad es aceptada o rechazado, etc.
