[ 
{ "author" : "FG98",
    "index": 1,
    "soal": "Animales como las lagartijas que pueden cambiar el color de su piel.?",
    "jawaban": "Camaleón"
  },
  { "author" : "FG98",
    "index": 2,
    "soal": "Carta de instrucción a Suharto para hacerse cargo de la seguridad de Indonesia el 11 de marzo de 1966?",
    "jawaban": "Supersemar"
  },
  { "author" : "FG98",
    "index": 3,
    "soal": "El río más largo de América?",
    "jawaban": "Amazon"
  },
  { "author" : "FG98",
    "index": 6,
    "soal": "¿El nombre de la película que cuenta la historia de un robot que puede convertirse en vehículo?",
    "jawaban": "Transformers"
  },
  { "author" : "FG98",
    "index": 7,
    "soal": "¿El nombre del lujoso barco de pasajeros que se hundió durante su viaje inaugural en 1912?",
    "jawaban": "Titanic"
  }
] 